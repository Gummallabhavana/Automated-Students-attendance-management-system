
import java.awt.Font;
import java.awt.*;
import javax.swing.*;
import javax.swing.JComboBox;
import java.awt.event.*;
import java.sql.*;

public class Register implements ActionListener
{
	JFrame frame2=new JFrame();
	JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10;
	JTextField t1,t2,t3,t4,t5,t6,t7;
	JButton b1,b2,b3,b4;
	JRadioButton male,btech;
    JRadioButton female,mtech;
    ButtonGroup gengp,course;
	JComboBox cb;
	String dates[]= { "1", "2", "3", "4", "5","6", "7", "8", "9", "10","11", "12", "13", "14", "15","16", "17", "18", "19", "20","21", "22", "23", "24", "25","26", "27", "28", "29", "30","31" };
    String months[]= { "Jan", "feb", "Mar", "Apr","May", "Jun", "July", "Aug","Sep", "Oct", "Nov", "Dec" };
    String years[]={ "1995", "1996", "1997", "1998","1999", "2000", "2001", "2002", "2003", "2004", "2005", "2006","2007", "2008", "2009", "2010","2011", "2012", "2013", "2014","2015", "2016", "2017", "2018","2019" ,"2020","2021","2022"};
	JComboBox date;
    JComboBox month;
    JComboBox year;
	JPanel pan;
	
	public Register()
	{
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		pan=new JPanel(null);
		pan.setBounds(150,100,600,500);
		
        l1 = new JLabel("Registration Form ");  
        l1.setForeground(Color.RED);  
        l1.setFont(new Font("Serif", Font.BOLD, 20));
        l1.setBounds(230, 30, 400, 30); 
		pan.add(l1);
		
        l2 = new JLabel("Roll Number : ");
        l2.setBounds(80, 70, 200, 30);
		pan.add(l2);		
		
        l3 = new JLabel("Student Name : ");   
        l3.setBounds(80, 110, 200, 30);
		pan.add(l3);
		
        l4 = new JLabel("Biometric code : ");  
        l4.setBounds(80, 150, 200, 30);
		pan.add(l4);
		
        l5 = new JLabel("Gender : ");     
        l5.setBounds(80, 190, 200, 30);  
		pan.add(l5);
		
        l6 = new JLabel("Branch : "); 
        l6.setBounds(80, 230, 200, 30); 
		pan.add(l6);
		
        l7 = new JLabel("Year of Joining : "); 
        l7.setBounds(80, 270, 200, 30); 
		pan.add(l7);
		
        l8 = new JLabel("Course : ");
        l8.setBounds(80, 310, 200, 30);
		pan.add(l8);
		
		/*l9=new JLabel("Academic year : ");
		l9.setBounds(80,350,200,30);
		pan.add(l9);*/
		
		
        t1 = new JTextField(); 
        t1.setBounds(300, 70, 200, 30);  
		pan.add(t1);
		
		
        t2 = new JTextField();  
        t2.setBounds(300, 110, 200, 30); 
		pan.add(t2);
		
        t3 = new JTextField();
        t3.setBounds(300, 150, 200, 30);
        pan.add(t3);
		
		male = new JRadioButton("Male");
        male.setBounds(300,190,75,30);
        pan.add(male);
 
        female = new JRadioButton("Female");
        female.setBounds(375,190,75,30);
        pan.add(female);
 
        gengp = new ButtonGroup();
        gengp.add(male);
        gengp.add(female);
		
		String[] choices = { "CIVIL","CSE", "IT","AIML","MECH","ECE","EEE"};
        cb = new JComboBox(choices);
		cb.setBounds(300, 230, 200, 30);
        cb.setVisible(true);
		pan.add(cb);
		
		date = new JComboBox(dates);
        date.setBounds(300,270,50,20);
        pan.add(date);
 
        month = new JComboBox(months);
        month.setBounds(350,270,60,20);
        pan.add(month);
 
        year = new JComboBox(years);
        year.setBounds(410,270,60,20);
        pan.add(year);
		
		btech = new JRadioButton("Btech");
        btech.setBounds(300,310,75,30);
        pan.add(btech);
 
        mtech = new JRadioButton("Mtech");
        mtech.setBounds(375,310,75,30);
        pan.add(mtech);
 
        course = new ButtonGroup();
        course.add(btech);
        course.add(mtech);
		
		/*t4 = new JTextField("eg:2020-2024"); 
        t4.setBounds(300,350,200,30);		
		t4.setText("");
		pan.add(t4); */
		
		
        b1 = new JButton("Submit");  
        b1.setBounds(200, 350, 100, 30);
		pan.add(b1);
		
        b2 = new JButton("Clear");    
        b2.setBounds(320, 3500, 100, 30);  
		pan.add(b2);
		
		b3=new JButton("<Back");
		b3.setBounds(50,400,100,30);
		pan.add(b3);
		
		
        frame2.add(pan);
		
		frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame2.getContentPane().setBackground(Color.gray);
	
		frame2.setTitle("STUDENTS BIOMETRIC BASED AUTOMATED attendence management system/Register");
		frame2.setSize(1000, 700);
		frame2.setLayout(null);
		frame2.setVisible(true);

        b1.addActionListener(this);
        b2.addActionListener(this);
        b3.addActionListener(this);	
	}
	
	private void displaySQLErrors(SQLException ea) 
	{
		JOptionPane.showMessageDialog(frame2,"\nSQLException: " + ea.getMessage() + "\n"+"SQLState:     " + ea.getSQLState() + "\n"+"VendorError:  " + ea.getErrorCode() + "\n");
	}
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==b1)
		{
			//frame2.dispose();
			try
			{
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:8080/ABSA","root","root");
				/*
				String rollnumber=t1.getText();
				String sname=t2.getText();
				String biocode=t3.getText();
				String gend=gengp.getSelection().getActionCommand();
				*/
				String sql,sqll;
				sql=" insert into students (roll_number,stu_name,sbt_code,gender)" + " values (?, ?, ?, ?)";
				PreparedStatement Stmt = con.prepareStatement(sql);
				Stmt.setString (1, t1.getText());
				Stmt.setString (2, t2.getText());
				Stmt.setString(3, t3.getText());
				String b;		
				if(male.isSelected())
				{
					b="male";
				}					
				else
				{
					b="female";
				}
				Stmt.setString(4,b);
				int  i = Stmt.executeUpdate();
				
				sqll=" insert into courses (roll_number,branch,year_of_joining,btech_or_mtech)" + " values (?, ?, ?, ?)";
				PreparedStatement Stmtt = con.prepareStatement(sqll);
				Stmtt.setString (1, t1.getText());
				Stmtt.setString (2,cb.getSelectedItem().toString());
				Stmtt.setString(3, date.getSelectedItem()+"-"+month.getSelectedItem()+"-"+year.getSelectedItem().toString());
				String a;		
				if(btech.isSelected())
				{
					a="btech";
				}					
				else
				{
					a="mtech";
				}
				Stmtt.setString(4,a);
				
				int  j = Stmtt.executeUpdate();
				if(i > 0 && j>0)
				{
					JOptionPane.showMessageDialog(frame2,"\nRegistered successfully");t1.setText("");
					t2.setText("");
					t3.setText("");
					t4.setText("");
					male.setSelected(false);
					female.setSelected(false);
					btech.setSelected(false);
					mtech.setSelected(false);
					cb.setSelectedIndex(0);
					date.setSelectedIndex(0);
					month.setSelectedIndex(0);
					year.setSelectedIndex(0);
			
			    }
				else
				{
					JOptionPane.showMessageDialog(frame2,"enter valid details");t2.setText("");
					t3.setText("");
					t4.setText("");
					male.setSelected(false);
					female.setSelected(false);
					btech.setSelected(false);
					mtech.setSelected(false);
					cb.setSelectedIndex(0);
					date.setSelectedIndex(0);
					month.setSelectedIndex(0);
					year.setSelectedIndex(0);
				}
			}
			catch(SQLException ea) 
			{
				displaySQLErrors(ea);
			}
			
		}
		if(e.getSource()==b2)
		{
			t1.setText("");
			t2.setText("");
			t3.setText("");
			t4.setText("");
			male.setSelected(false);
			female.setSelected(false);
			btech.setSelected(false);
			mtech.setSelected(false);
			cb.setSelectedIndex(0);
			date.setSelectedIndex(0);
            month.setSelectedIndex(0);
            year.setSelectedIndex(0);
			
		}
		if(e.getSource()==b3)
		{
			frame2.dispose();
			mainpage mp=new mainpage();
		}
	}
	/*public static void main(String[] args)
	{
		new Register();
	}*/
}