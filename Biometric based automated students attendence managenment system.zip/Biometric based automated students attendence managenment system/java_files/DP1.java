
import java.awt.Font;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class DP1 extends JPanel
{
	JLabel l2,l3,l4,l5,l1;
	JTextField t1,t2,t3;
	JRadioButton male;
    JRadioButton female;
	ButtonGroup gengp;
	JButton b1;	
    JPanel pp,p1;
	List ProjectList;
	
    public DP1() 
	{
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		
		l1=new JLabel("Enter the below fields to delete an existing record into Student's table");
        l1.setForeground(Color.BLUE);  
        l1.setFont(new Font("Serif", Font.BOLD, 15));
		l1.setBounds(80,10,500,30);
		
		
		l2 = new JLabel("Roll Number : ");
        l2.setBounds(80, 70, 200, 30);
				
        l3 = new JLabel("Student Name : ");   
        l3.setBounds(80, 110, 200, 30);
		
        l4 = new JLabel("Biometric code : ");  
        l4.setBounds(80, 150, 200, 30);
		
        l5 = new JLabel("Gender : ");     
        l5.setBounds(80, 190, 200, 30);  
	    
		t1 = new JTextField(); 
        t1.setBounds(300, 70, 200, 30);  
		
        t2 = new JTextField();  
        t2.setBounds(300, 110, 200, 30); 
		
        t3 = new JTextField();
        t3.setBounds(300, 150, 200, 30);
		
		male = new JRadioButton("Male");
        male.setBounds(300,190,75,30);
 
        female = new JRadioButton("Female");
        female.setBounds(375,190,75,30);
 
        gengp = new ButtonGroup();
        gengp.add(male);
        gengp.add(female);
		
		setLayout(null);
		setBounds(10,50,600,500);
		add(l1);
		add(l2);
		add(l3);
		add(l4);
		add(l5);
		add(t1);
		add(t2);
		add(t3);
		add(male);
		add(female);
		b1=new JButton("delete");
		b1.setBounds(250,240,100,30);
		add(b1); 
		
		ProjectList = new List(10);
		loadproject();
		ProjectList.setBounds(50, 280, 150, 80);
		add(ProjectList);  
		
		b1.addActionListener(new dpp1());
		
		ProjectList.addItemListener(new ItemListener() 
		{
			public void itemStateChanged(ItemEvent ievt)
			{
				try 
				{
					Connection con3 = DriverManager.getConnection("jdbc:mysql://localhost:8080/ABSA","root","root"); 
					Statement st3 = con3.createStatement();
					ResultSet rs3 = st3.executeQuery("select * from students");
					while (rs3.next()) 
					{
						if (rs3.getString("roll_number").equals(ProjectList.getSelectedItem()))
						break;
					}
					if (!rs3.isAfterLast()) 
					{
						t1.setText(rs3.getString("roll_number"));
						t2.setText(rs3.getString("stu_name"));
						t3.setText(rs3.getString("sbt_code"));
								
						if(rs3.getString("gender")=="male")
						{
							male.setSelected(true);
						}
						else
						{
							female.setSelected(true);
						}
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}	
			}
		});
		
	}
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(DP1.this,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
	}
	public void loadproject()
	{
		try{
			ProjectList = new List();
			ProjectList.removeAll();
			Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost:8080/ABSA","root","root"); 
			Statement st2 = con1.createStatement();
			ResultSet rs2 = st2.executeQuery("select * from students");
			while(rs2.next()) 
			{
				ProjectList.add(rs2.getString("roll_number"));
			}
			con1.close();
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
	public class dpp1 implements ActionListener
    {
		public void actionPerformed(ActionEvent aevt)
		{
			try 
			{
				int a = JOptionPane.showConfirmDialog(DP1.this,"Are you sure want to Delete:");
				if(a == JOptionPane.YES_OPTION)
				{  
					String query = "DELETE FROM students WHERE roll_number = ?";
					Connection con6 = DriverManager.getConnection("jdbc:mysql://localhost:8080/ABSA","root","root"); 
					PreparedStatement stp3 = con6.prepareStatement(query);
					stp3.setString(1, t1.getText());								
					int i = stp3.executeUpdate();
					if(i > 0)
					{
						JOptionPane.showMessageDialog(DP1.this,"\nDeleted  rows succesfully");
						t1.setText("");
						t2.setText(" ");
						t3.setText(" ");
						male.setSelected(false);
						female.setSelected(false);
						loadproject();			
					}
					con6.close();
				}
			 }
			catch(SQLException e)
			{
				displaySQLErrors(e);
			}
		}
	}
}
