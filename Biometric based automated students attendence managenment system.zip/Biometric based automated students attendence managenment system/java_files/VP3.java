import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Properties;
import javax.swing.table.DefaultTableModel;

public class VP3 extends JPanel
{
	JLabel view;
	public VP3()
	{
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		view = new JLabel("attendence View");
		view.setForeground(Color.red);
		Font myFont = new Font("Serif",Font.BOLD,20);
		view.setFont((myFont));
		view.setBounds(80,10,500,40);
		add(view);
		setLayout(null);
		setBounds(5,50,550,600);
		
		JTable jt;
		DefaultTableModel model = new DefaultTableModel(); 
		jt = new JTable(model); 
		model.addColumn("roll_number");
		model.addColumn("date");
		model.addColumn("present_or_absent");
	    try 
		{		
			Connection con7 = DriverManager.getConnection("jdbc:mysql://localhost:8080/ABSA","root","root"); 
			Statement st4 = con7.createStatement();
			ResultSet rs5;
			rs5 = st4.executeQuery("select * from attendence");
			while(rs5.next())
			{
				model.addRow(new Object[]{rs5.getString("roll_number"), rs5.getString("date"), rs5.getString("present_or_absent")});
			}
			con7.close();
		}
		catch(SQLException e)
		{
			displaySQLErrors(e);
		}
		
		jt.setEnabled(false);
		jt.setBounds(150, 300, 350, 300); 
        JScrollPane jsp = new JScrollPane(jt); 
		jsp.setBounds(40,80,500,350);
		add(jsp);
	}
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(VP3.this,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
	}		
}
