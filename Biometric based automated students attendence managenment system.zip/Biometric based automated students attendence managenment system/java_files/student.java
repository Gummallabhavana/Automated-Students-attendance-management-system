
import java.awt.Font;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class student
{
	JFrame frame5=new JFrame();
	JMenuBar mb;
	JMenu s,cd,at;
    JMenuItem u1, u2, v1,v2,i3,v3;
	JButton back;
	JLabel labe,l1,wel,come;
	JPanel p1,mp;
	
	insat inspat;
		
	vie1 vpstu;
	
	vie3 vpstuat;
	String rn;
	
	public student()
	{
		mb = new JMenuBar();
		s = new JMenu("Students");
		at = new JMenu("Attendence");
		
		v1 = new JMenuItem("View_details");
		i3 = new JMenuItem("mark_attendence");
		v3 = new JMenuItem("View_attendence's");
		
		s.add(v1);
		at.add(i3);
		at.add(v3);
		mb.add(s);
		mb.add(at);
		frame5.setJMenuBar(mb);
		
		mp=new JPanel(null);
		mp.setBounds(170,100,600,500);
		 
		l1=new JLabel("Welcome Student....");
		l1.setBounds(100,200,200,50);
		mp.add(l1);
		frame5.add(mp);
		
		p1 = new JPanel(null);
		p1.setBounds(20,20,920,70);
		back=new JButton("<Back");
		back.setBounds(10,10,80,20);
		p1.add(back);
		wel=new JLabel("welcome ");
		wel.setBounds(400,10,100,30);
		p1.add(wel);
		come=new JLabel();
		come.setBounds(480,10,100,30);
		p1.add(come);
		labe = new JLabel(" BIOMETRIC BASED AUTOMATED attendence PORTAL/Student Page ");
		labe.setBounds(300,40,800,30);
		p1.add(labe);
		p1.setBackground(Color.lightGray);
		frame5.add(p1);
		
		i3.addActionListener(new ins3());
		
		v1.addActionListener(new view1());
		
		v3.addActionListener(new view3());
		
		back.addActionListener(new backk());
			
		frame5.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame5.getContentPane().setBackground(Color.gray);
		frame5.setTitle("STUDENTS BIOMETRIC BASED AUTOMATED attendence management system/studentspage");
		frame5.setSize(1000, 700);
		frame5.setLayout(null);
		frame5.setVisible(true);
	}
	
    public void comern(String val)
	{
		rn=val;
		come.setText(rn);
		
	}		
	public class backk implements ActionListener
    {
		public void actionPerformed(ActionEvent ae) 
		{
			frame5.dispose();
			mainpage mp=new mainpage();
		}
		
	}
	
	public class ins3 implements ActionListener
    {
		public void actionPerformed(ActionEvent ae) 
		{
			inspat = new insat();
			
			mp.removeAll();
			mp.repaint();
			mp.revalidate();
			mp.add(inspat);
			mp.repaint();
			mp.revalidate();
		}
	}
	
	public class view1 implements ActionListener
    {
		public void actionPerformed(ActionEvent ae) 
		{
			vpstu = new vie1(rn);
			
			mp.removeAll();
			mp.repaint();
			mp.revalidate();
			mp.add(vpstu);
			mp.repaint();
			mp.revalidate();
		}
	}
	
	
	public class view3 implements ActionListener
    {
		public void actionPerformed(ActionEvent ae) 
		{
			vpstuat = new vie3(rn);
			
			mp.removeAll();
			mp.repaint();
			mp.revalidate();
			mp.add(vpstuat);
			mp.repaint();
			mp.revalidate();
		}
	}
	
}