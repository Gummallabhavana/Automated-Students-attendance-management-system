
import java.awt.Font;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.JComboBox;
import java.sql.*;

public class IP4 extends JPanel
{
	JLabel l1,l2,l3,l4,l5;
	JTextField t1,t2,t3;
	
	
	JButton b1;	
	
    public IP4() 
	{
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		
		l5=new JLabel("Enter the below fields to insert a new record into admin table");
        l5.setForeground(Color.BLUE);  
        l5.setFont(new Font("Serif", Font.BOLD, 15));
		l5.setBounds(80,10,500,30);
		
		l1 = new JLabel("Username : ");
        l1.setBounds(80, 70, 200, 30);
		
		l2 = new JLabel("Password : "); 
        l2.setBounds(80, 110, 200, 30); 
		
		t1 = new JTextField(); 
        t1.setBounds(300, 70, 200, 30);  
		
		t2 = new JTextField(); 
        t2.setBounds(300, 110, 200, 30);  
		
        
		setLayout(null);
		setBounds(10,50,600,500);
		add(l5);
		add(l1);
		add(l2);
		add(t1);
		add(t2);
		b1=new JButton("submit");
		b1.setBounds(250,240,100,30);
		add(b1);
		
    b1.addActionListener(new ins4());
    }
	
	
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(IP4.this,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
	}
	public class ins4 implements ActionListener
    {
		public void actionPerformed(ActionEvent ae) 
		{
			try
			{
				
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:8080/ABSA","root","root");
				String sql;
				sql=" insert into admin(username,password)" + " values ( ?, ?)";
				PreparedStatement Stmt = con.prepareStatement(sql);
				Stmt.setString (1, t1.getText());
				Stmt.setString(2, t2.getText());
				int  i = Stmt.executeUpdate();
				con.close();
				if(i > 0)
				{
					JOptionPane.showMessageDialog(IP4.this,"\nInserted successfully");
					t1.setText("");
					t2.setText("");
				}
			}
			catch(SQLException e) 
			{
				displaySQLErrors(e);
			}
		}
	}
}
