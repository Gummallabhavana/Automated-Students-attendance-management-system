
import java.awt.Font;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class loginadmin implements ActionListener
{
	JFrame frame3=new JFrame();
	JLabel l1,l2,l3;
	JTextField t1,t2;
	JButton b1,b2;
	JPanel pan;
	
	public loginadmin()
	{
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		pan=new JPanel(null);
		pan.setBounds(200,100,600,400);
		
		l1=new JLabel("LOGIN FORM (ADMIN)");
		l1.setBounds(220,30,400,50);
		l1.setFont(new Font("Serif",Font.BOLD,18));
		l1.setForeground(Color.red);
		pan.add(l1);
		
		l2=new JLabel("Enter Username : ");
		l2.setBounds(200,80,200,50);
		pan.add(l2);
		
		t1=new JTextField();
		t1.setBounds(350,95,100,20);
		pan.add(t1);
		
		l3=new JLabel("Enter Password : ");
		l3.setBounds(200,130,200,50);
		pan.add(l3);
		
		t2=new JTextField();
		t2.setBounds(350,145,100,20);
		pan.add(t2);
		
		b1=new JButton("submit");
		b1.setBounds(280,200,100,30);
		pan.add(b1);
		
		b2=new JButton("< Back");
		b2.setBounds(50,300,100,30);
		pan.add(b2);
		
		frame3.add(pan);
		
		frame3.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame3.getContentPane().setBackground(Color.gray);
	
		frame3.setTitle("STUDENTS BIOMETRIC BASED AUTOMATED attendence management system");
		frame3.setSize(1000, 700);
		frame3.setLayout(null);
		frame3.setVisible(true);
		
		b1.addActionListener(this);
        b2.addActionListener(this);
	}
	private void displaySQLErrors(SQLException ea) 
	{
		JOptionPane.showMessageDialog(frame3,"\nSQLException: " + ea.getMessage() + "\n"+"SQLState:     " + ea.getSQLState() + "\n"+"VendorError:  " + ea.getErrorCode() + "\n");
	}
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==b1)
		{
			try
			{
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:8080/ABSA","root","root");
				Statement stmt=con.createStatement();
				String sql="Select username,password from admin where username=? and password=?";
				PreparedStatement st=con.prepareStatement(sql);
				st.setString(1,t1.getText());
				st.setString(2,t2.getText());
				ResultSet rs=st.executeQuery();
				if(rs.next())
				{
					JOptionPane.showMessageDialog(frame3,"successfully logged in");
					frame3.dispose();
					Admin ad=new Admin();
					
				}
				else
				{
					JOptionPane.showMessageDialog(frame3,"wrong username and password");
				}
				
			}
			catch(SQLException ea) 
			{
				displaySQLErrors(ea);
			}
		}
		if(e.getSource()==b2)
		{
			frame3.dispose();
			mainpage mp=new mainpage();
		}
	}
	
	public static void main(String[] args)
	{
		new loginadmin();
	}
}