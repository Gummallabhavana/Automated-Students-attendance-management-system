import javax.swing.*;

public class launchpage
{
	public static void main(String[] args)
	{
		SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new mainpage();
            }
        });
	}
}