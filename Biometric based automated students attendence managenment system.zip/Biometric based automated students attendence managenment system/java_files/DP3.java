
import java.awt.Font;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.JComboBox;
import java.util.StringTokenizer;
import java.sql.*;

public class DP3 extends JPanel
{
	JLabel l1,l2,l3,l4,l5,l6;
	JTextField t1,t2,t3;
	JRadioButton pp,aa;
    ButtonGroup atnd;
	
	String dates[]= { "1", "2", "3", "4", "5","6", "7", "8", "9", "10","11", "12", "13", "14", "15","16", "17", "18", "19", "20","21", "22", "23", "24", "25","26", "27", "28", "29", "30","31" };
    String months[]= { "Jan", "feb", "Mar", "Apr","May", "Jun", "July", "Aug","Sep", "Oct", "Nov", "Dec" };
    String years[]={ "1995", "1996", "1997", "1998","1999", "2000", "2001", "2002", "2003", "2004", "2005", "2006","2007", "2008", "2009", "2010","2011", "2012", "2013", "2014","2015", "2016", "2017", "2018","2019" };
	JComboBox date;
    JComboBox month;
    JComboBox year;
	
	JButton b1;	
	List ProjectList;
	
    public DP3() 
	{
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		
		
		l5=new JLabel("Enter the below fields to delete an existing record into attendence table");
        l5.setForeground(Color.BLUE);  
        l5.setFont(new Font("Serif", Font.BOLD, 15));
		l5.setBounds(80,10,500,30);
		
		l1 = new JLabel("Roll Number : ");
        l1.setBounds(80, 70, 200, 30);
		
		l2 = new JLabel("Date (Today's) : "); 
        l2.setBounds(80, 110, 200, 30); 
		
		l3 = new JLabel(" present / absent : "); 
        l3.setBounds(80, 150, 200, 30); 
		
		t1 = new JTextField(); 
        t1.setBounds(300, 70, 200, 30);  
		
		date = new JComboBox(dates);
        date.setBounds(300,110,60,30);
       
        month = new JComboBox(months);
        month.setBounds(350,110,60,30);
       
        year = new JComboBox(years);
        year.setBounds(410,110,60,30);
       
	    pp = new JRadioButton("present");
        pp.setBounds(300,150,75,30);
        
        aa = new JRadioButton("absent");
        aa.setBounds(375,150,75,30);
        
        atnd = new ButtonGroup();
        atnd.add(pp);
        atnd.add(aa);
        
		setLayout(null);
		setBounds(10,50,600,500);
		add(l5);
		add(l1);
		add(l2);
		add(l3);
		add(t1);
		add(date);
		add(month);
		add(year);
		add(pp);
		add(aa);
		b1=new JButton("delete");
		b1.setBounds(250,240,100,30);
		add(b1);
		ProjectList = new List(10);
		loadproject();
		ProjectList.setBounds(50, 280, 150, 80);
		add(ProjectList);  
		
		b1.addActionListener(new dpp3());
		
		ProjectList.addItemListener(new ItemListener() 
		{
			public void itemStateChanged(ItemEvent ievt)
			{
				try 
				{
					Connection con3 = DriverManager.getConnection("jdbc:mysql://localhost:8080/ABSA","root","root"); 
					Statement st3 = con3.createStatement();
					ResultSet rs3 = st3.executeQuery("select * from attendence");
							while (rs3.next()) {
								if (rs3.getString("roll_number").equals(ProjectList.getSelectedItem()))
								break;
							}
							if (!rs3.isAfterLast()) {
								t1.setText(rs3.getString("roll_number"));
								//t2.setText(rs3.getString("date"));
								
								StringTokenizer st=new StringTokenizer(rs3.getString("date"),"-");
								while(st.hasMoreElements())
								{
									date.setSelectedItem(st.nextToken());
									month.setSelectedItem(st.nextToken());
									year.setSelectedItem(st.nextToken());
								}
								//t3.setText(rs3.getString("present_or_absent"));
								if(rs3.getString("present_or_absent")=="present")
								{
									pp.setSelected(true);
								}
								else
								{
									aa.setSelected(true);
								}
								
							}
						} 
						catch (SQLException selectException) {
							displaySQLErrors(selectException);
						}	
			}
		});
		
	}
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(DP3.this,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
	}
	public void loadproject()
	{
		try{
			ProjectList = new List();
			ProjectList.removeAll();
			Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost:8080/ABSA","root","root"); 
			Statement st2 = con1.createStatement();
			ResultSet rs2 = st2.executeQuery("select * from attendence");
			while(rs2.next()) 
			{
				ProjectList.add(rs2.getString("roll_number"));
			}
			con1.close();
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
	public class dpp3 implements ActionListener
    {
		public void actionPerformed(ActionEvent aevt)
		{
			try 
			{
				int a = JOptionPane.showConfirmDialog(DP3.this,"Are you sure want to Delete:");
				if(a == JOptionPane.YES_OPTION)
				{  
					String query = "DELETE FROM attendence WHERE roll_number = ?";
					Connection con6 = DriverManager.getConnection("jdbc:mysql://localhost:8080/ABSA","root","root"); 
					PreparedStatement stp3 = con6.prepareStatement(query);
					stp3.setString(1, t1.getText());								
					int i = stp3.executeUpdate();
					if(i > 0)
					{
						JOptionPane.showMessageDialog(DP3.this,"\nDeleted  rows succesfully");
						t1.setText("");
						date.setSelectedIndex(0);
						month.setSelectedIndex(0);
						year.setSelectedIndex(0);
						pp.setSelected(false);
						aa.setSelected(false);
						loadproject();			
					}
					con6.close();
				}
			 }
			catch(SQLException e)
			{
				displaySQLErrors(e);
			}
		}
	}
}

