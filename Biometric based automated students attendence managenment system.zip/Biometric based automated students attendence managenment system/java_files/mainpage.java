
import java.awt.Font;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class mainpage implements ActionListener
{
	JFrame frame=new JFrame();
	JPanel pan;
	JLabel info,hyp;
	JButton lps,lpa,rp,ap,ch;
	
	
	public mainpage()
	{
		pan=new JPanel(null);
		pan.setBounds(200,100,600,400);
		
		info=new JLabel("STUDENTS BIOMETRIC BASED AUTOMATED attendence ");
		info.setBounds(30,50,500,50);
		info.setFont(new Font("Serif",Font.BOLD,18));
		info.setForeground(Color.RED);
		pan.add(info);
		
		lps=new JButton("Login(student)");
		lps.setBounds(200,120,200,30);
		pan.add(lps);
		
		lpa=new JButton("Login(admin)");
		lpa.setBounds(200,170,200,30);
		pan.add(lpa);
		
		rp=new JButton("register");
		rp.setBounds(200,220,200,30);
		pan.add(rp);
		
		frame.add(pan);
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setBackground(Color.gray);
	
		frame.setTitle("STUDENTS BIOMETRIC BASED AUTOMATED attendence management system");
		frame.setSize(1000, 700);
		frame.setLayout(null);
		frame.setVisible(true);
		
		lps.addActionListener(this);
		lpa.addActionListener(this);
		rp.addActionListener(this);
		
	}
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==lps)
		{
			frame.dispose();
			loginstudent lsp =new loginstudent();			
		}
		if(e.getSource()==lpa)
		{
			frame.dispose();
			loginadmin lap =new loginadmin();			
		}
		if(e.getSource()==rp)
		{
			frame.dispose();
			Register rrp =new Register();			
		}
	}
}