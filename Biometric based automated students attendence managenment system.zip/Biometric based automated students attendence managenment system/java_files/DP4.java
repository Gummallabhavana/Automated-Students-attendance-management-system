
import java.awt.Font;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.JComboBox;
import java.sql.*;

public class DP4 extends JPanel
{
	JLabel l1,l2,l3,l4,l5;
	JTextField t1,t2,t3;
	
	
	JButton b1;	
	List ProjectList;
	
    public DP4() 
	{
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		
		
		l5=new JLabel("Enter the below fields to delete an existing record into admin table");
        l5.setForeground(Color.BLUE);  
        l5.setFont(new Font("Serif", Font.BOLD, 15));
		l5.setBounds(80,10,500,30);
		
		l1 = new JLabel("Username : ");
        l1.setBounds(80, 70, 200, 30);
		
		l2 = new JLabel("Password : "); 
        l2.setBounds(80, 110, 200, 30); 
		
		t1 = new JTextField(); 
        t1.setBounds(300, 70, 200, 30);  
		
		t2 = new JTextField(); 
        t2.setBounds(300, 110, 200, 30);  
		
        
		setLayout(null);
		setBounds(10,50,600,500);
		add(l5);
		add(l1);
		add(l2);
		add(t1);
		add(t2);
		b1=new JButton("delete");
		b1.setBounds(250,240,100,30);
		add(b1);
		
		ProjectList = new List(10);
		loadproject();
		ProjectList.setBounds(50, 280, 150, 80);
		add(ProjectList);  
		
		b1.addActionListener(new dpp4());
		
		ProjectList.addItemListener(new ItemListener() 
		{
			public void itemStateChanged(ItemEvent ievt)
			{
				try 
				{
					Connection con3 = DriverManager.getConnection("jdbc:mysql://localhost:8080/ABSA","root","root"); 
					Statement st3 = con3.createStatement();
					ResultSet rs3 = st3.executeQuery("select * from admin");
							while (rs3.next()) {
								if (rs3.getString("username").equals(ProjectList.getSelectedItem()))
								break;
							}
							if (!rs3.isAfterLast()) {
								t1.setText(rs3.getString("username"));
								t2.setText(rs3.getString("password"));
							}
						} 
						catch (SQLException selectException) {
							displaySQLErrors(selectException);
						}	
			}
		});
		
	}
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(DP4.this,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
	}
	public void loadproject()
	{
		try{
			ProjectList = new List();
			ProjectList.removeAll();
			Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost:8080/ABSA","root","root"); 
			Statement st2 = con1.createStatement();
			ResultSet rs2 = st2.executeQuery("select * from admin");
			while(rs2.next()) 
			{
				ProjectList.add(rs2.getString("username"));
			}
			con1.close();
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
	public class dpp4 implements ActionListener
    {
		public void actionPerformed(ActionEvent aevt)
		{
			try 
			{
				int a = JOptionPane.showConfirmDialog(DP4.this,"Are you sure want to Delete:");
				if(a == JOptionPane.YES_OPTION)
				{  
					String query = "DELETE FROM admin WHERE username = ?";
					Connection con6 = DriverManager.getConnection("jdbc:mysql://localhost:8080/ABSA","root","root"); 
					PreparedStatement stp3 = con6.prepareStatement(query);
					stp3.setString(1, t1.getText());								
					int i = stp3.executeUpdate();
					if(i > 0)
					{
						JOptionPane.showMessageDialog(DP4.this,"\nDeleted  rows succesfully");
						t1.setText("");
						t2.setText(" ");
						loadproject();			
					}
					con6.close();
				}
			 }
			catch(SQLException e)
			{
				displaySQLErrors(e);
			}
		}
	}
}
