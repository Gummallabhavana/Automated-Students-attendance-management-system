import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Properties;
import javax.swing.table.DefaultTableModel;

public class VP1 extends JPanel
{
	//	JFrame frame;
	//JButton back;
	JLabel view;
	public VP1()
	{
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		//frame=new JFrame();
		//back=new JButton("<Back");
		//back.setBounds(20,50,100,30);
		//frame.add(back);
		view = new JLabel("students View");
		view.setForeground(Color.red);
		//JB_view = new JButton("View");
		Font myFont = new Font("Serif",Font.BOLD,20);
		view.setFont((myFont));
		view.setBounds(80,10,500,40);
		//JPanel pan=new JPanel(null);
		//frame.add(view);
		add(view);
		setLayout(null);
		setBounds(5,50,550,600);
		
		JTable jt;
		DefaultTableModel model = new DefaultTableModel(); 
		jt = new JTable(model); 
		model.addColumn("roll_number");
		model.addColumn("stu_name");
		model.addColumn("sbt_code");
        model.addColumn("gender");
	    try 
		{		
			Connection con7 = DriverManager.getConnection("jdbc:mysql://localhost:8080/ABSA","root","root"); 
			Statement st4 = con7.createStatement();
			ResultSet rs5 = st4.executeQuery("select * from students");
			rs5 = st4.executeQuery("select * from students");
			while(rs5.next())
			{
				model.addRow(new Object[]{rs5.getString("roll_number"), rs5.getString("stu_name"), rs5.getString("sbt_code"), rs5.getString("gender")});
			}
			con7.close();
		}
		catch(SQLException e)
		{
			displaySQLErrors(e);
		}
		
		jt.setEnabled(false);
		jt.setBounds(150, 300, 350, 300); 
        JScrollPane jsp = new JScrollPane(jt); 
		jsp.setBounds(40,80,500,350);
		add(jsp);
	}
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(VP1.this,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
	}		
}
