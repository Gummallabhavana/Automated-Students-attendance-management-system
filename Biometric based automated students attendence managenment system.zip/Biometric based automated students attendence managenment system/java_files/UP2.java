
import java.awt.Font;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.JComboBox;
import java.sql.*;
import java.util.StringTokenizer;

public class UP2 extends JPanel
{
	JLabel l1,l2,l3,l4,l5,l6;
	JTextField t1,t2,t3;
	JRadioButton btech,mtech;
    ButtonGroup course;
	JComboBox cb;
	String dates[]= { "1", "2", "3", "4", "5","6", "7", "8", "9", "10","11", "12", "13", "14", "15","16", "17", "18", "19", "20","21", "22", "23", "24", "25","26", "27", "28", "29", "30","31" };
    String months[]= { "Jan", "feb", "Mar", "Apr","May", "Jun", "July", "Aug","Sep", "Oct", "Nov", "Dec" };
    String years[]={ "1995", "1996", "1997", "1998","1999", "2000", "2001", "2002", "2003", "2004", "2005", "2006","2007", "2008", "2009", "2010","2011", "2012", "2013", "2014","2015", "2016", "2017", "2018","2019" };
    String[] choices = { "CIVIL","CSE", "IT","AIML","MECH","ECE","EEE"};
	JComboBox date;
    JComboBox month;
    JComboBox year;
	
	JButton b1;	
	List ProjectList;
	
    public UP2() 
	{
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		l6=new JLabel("Enter the below fields to update an existing record into course table");
        l6.setForeground(Color.BLUE);  
        l6.setFont(new Font("Serif", Font.BOLD, 15));
		l6.setBounds(80,10,500,30);
		
		l1 = new JLabel("Roll Number : ");
        l1.setBounds(80, 70, 200, 30);
		
		l2 = new JLabel("Branch : "); 
        l2.setBounds(80, 110, 200, 30); 
		
		l3 = new JLabel("Year of Joining : "); 
        l3.setBounds(80, 150, 200, 30); 
		
        l4 = new JLabel("Course : ");
        l4.setBounds(80, 190, 200, 30);
		
		t1 = new JTextField(); 
        t1.setBounds(300, 70, 200, 30);  
		
        cb = new JComboBox(choices);
		cb.setBounds(300, 110, 200, 30);
        cb.setVisible(true); 
		
		date = new JComboBox(dates);
        date.setBounds(300,150,60,30);
       
        month = new JComboBox(months);
        month.setBounds(360,150,60,30);
       
        year = new JComboBox(years);
        year.setBounds(420,150,60,30);
       
	    btech = new JRadioButton("Btech");
        btech.setBounds(300,190,75,30);
        
        mtech = new JRadioButton("Mtech");
        mtech.setBounds(375,190,75,30);
        
        course = new ButtonGroup();
        course.add(btech);
        course.add(mtech);
        
		setLayout(null);
		setBounds(10,50,600,500);
		add(l6);
		add(l1);
		add(l2);
		add(l3);
		add(l4);
		add(t1);
		add(cb);
		add(date);
		add(month);
		add(year);
		add(btech);
		add(mtech);
		b1=new JButton("modify");
		b1.setBounds(250,240,100,30);
		add(b1);
		
		ProjectList = new List(10);
		loadproject();
		ProjectList.setBounds(50, 280, 150, 80);
		add(ProjectList);  
		
		b1.addActionListener(new upp2());
		
		ProjectList.addItemListener(new ItemListener() {
					public void itemStateChanged(ItemEvent ievt){
						try {
							Connection con3 = DriverManager.getConnection("jdbc:mysql://localhost:8080/ABSA","root","root"); 
							Statement st3 = con3.createStatement();
							ResultSet rs3 = st3.executeQuery("select * from courses");
							while (rs3.next()) {
								if (rs3.getString("roll_number").equals(ProjectList.getSelectedItem()))
								break;
							}
							if (!rs3.isAfterLast()) {
								t1.setText(rs3.getString("roll_number"));
						
								cb.setSelectedItem(rs3.getString("branch"));
								/*
								for(int i=0;i<choices.length;i++)
								{
									if(a1.equals(choices))
								}*/
								
								StringTokenizer st=new StringTokenizer(rs3.getString("year_of_joining"),"-");
								while(st.hasMoreElements())
								{
									date.setSelectedItem(st.nextToken());
									month.setSelectedItem(st.nextToken());
									year.setSelectedItem(st.nextToken());
								}
								
								if(rs3.getString("btech_or_mtech")=="btech")
								{
									btech.setSelected(true);
								}
								else
								{
									mtech.setSelected(true);
								}
								con3.close();
							}
						} 
						catch (SQLException selectException) {
							displaySQLErrors(selectException);
						}	
					}
				});
		
	}
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(UP2.this,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
	}
	public void loadproject()
	{
		try{
			ProjectList = new List();
			ProjectList.removeAll();
			Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost:8080/ABSA","root","root"); 
			Statement st2 = con1.createStatement();
			ResultSet rs2 = st2.executeQuery("select * from  courses");
			while(rs2.next()) 
			{
				ProjectList.add(rs2.getString("roll_number"));
			}
			con1.close();
		}
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
	public class upp2 implements ActionListener
    {
		public void actionPerformed(ActionEvent ae) 
		{
			try
			{
				int a = JOptionPane.showConfirmDialog(UP2.this, "Are you sure want to update:");
				if(a == JOptionPane.YES_OPTION)
				{  
					String query = "update courses set branch = ?, year_of_joining = ?, btech_or_mtech = ? where roll_number = ?"; 
					Connection con4 = DriverManager.getConnection("jdbc:mysql://localhost:8080/ABSA","root","root"); 
					PreparedStatement Stmt = con4.prepareStatement(query);
					Stmt.setString (4, t1.getText());
					Stmt.setString (1,cb.getSelectedItem().toString());
					Stmt.setString(2, date.getSelectedItem()+"-"+month.getSelectedItem()+"-"+year.getSelectedItem().toString());
					String b;		
					if(btech.isSelected())
					{
						b="btech";
					}					
					else
					{
						b="mtech";
					}
					Stmt.setString(3,b);
					int i = Stmt.executeUpdate();
					if(i>0)
					{
						JOptionPane.showMessageDialog(UP2.this,"\nUpdated rows succesfully");
						t1.setText("");
						cb.setSelectedIndex(0);
						date.setSelectedIndex(0);
						month.setSelectedIndex(0);
						year.setSelectedIndex(0);
						btech.setSelected(false);
						mtech.setSelected(false);
						loadproject();
					}
					con4.close();
				}
			}
			catch(SQLException e)
			{
				displaySQLErrors(e);
			}
		}
	}
}
