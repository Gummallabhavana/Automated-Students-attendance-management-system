import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Properties;
import javax.swing.table.DefaultTableModel;

public class vie1 extends JPanel
{
	JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,l14,l15,l16;
	//JTextField t1,t2,t3,t4,t5,t6,t7;
	
	String rn;
	public vie1(String val)
	{
		rn=val;
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		
		setLayout(null);
		setBounds(40,10,600,500);
		
		l1 = new JLabel("student's details");  
        l1.setForeground(Color.RED);  
        l1.setFont(new Font("Serif", Font.BOLD, 20));
        l1.setBounds(230, 10, 400, 30); 
		
        l2 = new JLabel("Roll Number : ");
        l2.setBounds(80, 50, 200, 30);
		
        l3 = new JLabel("Student Name : ");   
        l3.setBounds(80, 90, 200, 30);
		
        l4 = new JLabel("Biometric code : ");  
        l4.setBounds(80, 130, 200, 30);
		
        l5 = new JLabel("Gender : ");     
        l5.setBounds(80, 170, 200, 30);  
		
        l6 = new JLabel("Branch : "); 
        l6.setBounds(80, 210, 200, 30); 
		
        l7 = new JLabel("Year of Joining : "); 
        l7.setBounds(80, 250, 200, 30); 
		
        l8 = new JLabel("Course : ");
        l8.setBounds(80, 290, 200, 30);
		
	    l9 = new JLabel();
        l9.setBounds(300, 50, 200, 30);
		
        l10 = new JLabel();   
        l10.setBounds(300, 90, 200, 30);
		
        l11 = new JLabel();  
        l11.setBounds(300, 130, 200, 30);
		
        l12 = new JLabel();     
        l12.setBounds(300, 170, 200, 30);  
		
        l13 = new JLabel(); 
        l13.setBounds(300, 210, 200, 30); 
		
        l14 = new JLabel(); 
        l14.setBounds(300, 250, 200, 30); 
		
        l15 = new JLabel();
        l15.setBounds(300, 290, 200, 30);
			
		add(l1);
		add(l2);
		add(l3);
		add(l4);
		add(l5);
		add(l6);
		add(l7);
		add(l8);
		add(l9);
		add(l9);
		add(l10);
		add(l11);
		add(l12);
		add(l13);
		add(l14);
		add(l15);
		
		try
		{
			Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost:8080/ABSA","root","root"); 
			Statement st2 = con1.createStatement();
			ResultSet rs2 = st2.executeQuery("select s.roll_number,s.stu_name,s.sbt_code,s.gender,c.branch,c.year_of_joining,c.btech_or_mtech from students s , courses c where c.roll_number=s.roll_number && s.roll_number='"+rn+"'");
			while(rs2.next()) 
			{
				l9.setText(rs2.getString("roll_number"));
				l10.setText(rs2.getString("stu_name"));
				l11.setText(rs2.getString("sbt_code"));
				l12.setText(rs2.getString("gender"));
				l13.setText(rs2.getString("branch"));
				l14.setText(rs2.getString("year_of_joining"));
				l15.setText(rs2.getString("btech_or_mtech"));
			}
			con1.close();
		}	
		catch(SQLException e) 
		{
			displaySQLErrors(e);
		}
	}
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(vie1.this,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
	}
}