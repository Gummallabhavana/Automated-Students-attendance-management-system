
import java.awt.Font;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class loginstudent implements ActionListener
{
	JFrame frame1=new JFrame();
	JLabel l1,l2,l3,l4;
	JTextField t1,t2;
	JButton b1,b2,b3;
	JPanel pan;
	
	public loginstudent()
	{
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		pan=new JPanel(null);
		pan.setBounds(200,100,600,400);
		
		l1=new JLabel("LOGIN FORM (STUDENT)");
		l1.setBounds(220,30,400,50);
		l1.setFont(new Font("Serif",Font.BOLD,18));
		l1.setForeground(Color.RED);
		pan.add(l1);
		
		l2=new JLabel("Enter Roll Number : ");
		l2.setBounds(200,80,200,50);
		pan.add(l2);
		
		t1=new JTextField();
		t1.setBounds(350,95,100,20);
		pan.add(t1);
		
		l3=new JLabel("Enter Student Name : ");
		l3.setBounds(200,130,200,50);
		pan.add(l3);
		
		t2=new JTextField();
		t2.setBounds(350,145,100,20);
		pan.add(t2);
		
		b1=new JButton("submit");
		b1.setBounds(280,200,100,30);
		pan.add(b1);
		
		b2=new JButton("CLICK HERE");
		b2.setBounds(430,300,150,30);
		pan.add(b2);
		
		l4=new JLabel("to get register (if not registered!!)");
		l4.setBounds(390,330,300,30);
		l4.setFont(new Font("serif",Font.PLAIN,15));
		l4.setForeground(Color.BLUE);
		pan.add(l4);
		
		b3=new JButton("< Back");
		b3.setBounds(50,300,150,30);
		pan.add(b3);
		
		frame1.add(pan);
		
		frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame1.getContentPane().setBackground(Color.gray);
	
		frame1.setTitle("STUDENTS BIOMETRIC BASED AUTOMATED attendence management system");
		frame1.setSize(1000, 700);
		frame1.setLayout(null);
		frame1.setVisible(true);
		
		b1.addActionListener(this);
        b2.addActionListener(this);
		b3.addActionListener(this);
	}
	private void displaySQLErrors(SQLException ea) 
	{
		JOptionPane.showMessageDialog(frame1,"\nSQLException: " + ea.getMessage() + "\n"+"SQLState:     " + ea.getSQLState() + "\n"+"VendorError:  " + ea.getErrorCode() + "\n");
	}
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==b1)
		{
				
			try
			{
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:8080/ABSA","root","root");
				Statement stmt=con.createStatement();
				String sql="Select roll_number,stu_name from students where roll_number=? and stu_name=?";
				PreparedStatement st=con.prepareStatement(sql);
				st.setString(1,t1.getText());
				String rn=t1.getText();
				st.setString(2,t2.getText());
				ResultSet rs=st.executeQuery();
				if(rs.next())
				{
					JOptionPane.showMessageDialog(frame1,"successfully logged in");
					frame1.dispose();
					student stu=new student();
					stu.comern(rn);
					
				}
				else
				{
					JOptionPane.showMessageDialog(frame1,"wrong username and password");
				}
				
			}
			catch(SQLException ea) 
			{
				displaySQLErrors(ea);
			}
			
		}
		if(e.getSource()==b2)
		{
			frame1.dispose();
			Register rr=new Register();
		}
		if(e.getSource()==b3)
		{
			frame1.dispose();
			mainpage mp=new mainpage();
		}
	}
	
}