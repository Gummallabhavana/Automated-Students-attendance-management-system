
import java.awt.Font;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Admin //implements ActionListener
{
	JFrame frame4=new JFrame();
	JMenuBar mb;
	JMenu cd, s, at, ad;
    JMenuItem i1, u1, d1, v1;
	JMenuItem i2, u2, d2, v2;
	JMenuItem i3, u3, d3, v3;
	JMenuItem i4, u4, d4, v4;
	JPanel pa,p1,mp,mm;
	
	JLabel l1,labell,l;
	JTextField t1,t2,t3,t4;
	JButton b1,b2,b3,back;
	
	IP1 ipan1;
	IP2 ipan2;
	IP3 ipan3;
	IP4 ipan4;
		
	UP1 upan1;
	UP2 upan2;
	UP3 upan3;
	UP4 upan4;
	
	DP1 dpan1;
	DP2 dpan2;
	DP3 dpan3;
	DP4 dpan4;
	
	VP1 vpan1;
	VP2 vpan2;
	VP3 vpan3;
	VP4 vpan4;
	
	public Admin()
	{	
		mb = new JMenuBar();
		s = new JMenu("Students");
		cd = new JMenu("Course Details");
		at = new JMenu("Attendence Details");
		ad  = new JMenu("Admin");
		
		i1 = new JMenuItem("Insert");
		d1 = new JMenuItem("Delete");
		u1 = new JMenuItem("Update");
		v1 = new JMenuItem("View");
		i2 = new JMenuItem("Insert");
		d2 = new JMenuItem("Delete");
		u2 = new JMenuItem("Update");
		v2 = new JMenuItem("View");
		i3 = new JMenuItem("Insert");
		d3 = new JMenuItem("Delete");
		u3 = new JMenuItem("Update");
		v3 = new JMenuItem("View");
		i4 = new JMenuItem("Insert");
		d4 = new JMenuItem("Delete");
		u4 = new JMenuItem("Update");
		v4 = new JMenuItem("View");
		
		s.add(i1);
		s.add(d1);
		s.add(u1);
		s.add(v1);
		cd.add(i2);
		cd.add(d2);
		cd.add(u2);
		cd.add(v2);
		at.add(i3);
		at.add(d3);
		at.add(u3);
		at.add(v3);
		ad.add(i4);
		ad.add(d4);
		ad.add(u4);
		ad.add(v4);
		mb.add(s);
		mb.add(cd);
		mb.add(at);
		mb.add(ad);
		frame4.setJMenuBar(mb);
		
		mp=new JPanel(null);
		mp.setBounds(170,100,600,500);
		 
		l1=new JLabel("Welcome Admin....");
		l1.setBounds(100,200,200,50);
		mp.add(l1);
		frame4.add(mp);
		
		p1 = new JPanel(null);
		p1.setBounds(20,20,920,70);
		back=new JButton("<Back");
		back.setBounds(10,10,80,20);
		p1.add(back);
		l = new JLabel(" BIOMETRIC BASED AUTOMATED attendence PORTAL/ADMIN PAGE ");
		l.setBounds(300,40,800,30);
		p1.add(l);
		p1.setBackground(Color.pink);
		frame4.add(p1);
		
		i1.addActionListener(new insert1());
		i2.addActionListener(new insert2());
		i3.addActionListener(new insert3());
		i4.addActionListener(new insert4());
		
		d1.addActionListener(new delete1());
		d2.addActionListener(new delete2());
		d3.addActionListener(new delete3());
		d4.addActionListener(new delete4());
		
		u1.addActionListener(new update1());
		u2.addActionListener(new update2());
		u3.addActionListener(new update3());
		u4.addActionListener(new update4());
		
		v1.addActionListener(new view1());
		v2.addActionListener(new view2());
		v3.addActionListener(new view3());
		v4.addActionListener(new view4());
		
		back.addActionListener(new backk());
			
		frame4.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame4.getContentPane().setBackground(Color.gray);
		frame4.setTitle("STUDENTS BIOMETRIC BASED AUTOMATED attendence management system/Admin");
		frame4.setSize(1000, 700);
		frame4.setLayout(null);
		frame4.setVisible(true);
	}
	

	public class backk implements ActionListener
    {
		public void actionPerformed(ActionEvent ae) 
		{
			frame4.dispose();
			mainpage mp=new mainpage();
		}
		
	}
	
	public class insert1 implements ActionListener
    {
		public void actionPerformed(ActionEvent ae) 
		{
			ipan1 = new IP1();
			
			mp.removeAll();
			mp.repaint();
			mp.revalidate();
			mp.add(ipan1);
			mp.repaint();
			mp.revalidate();
		}
	}
	
	public class insert2 implements ActionListener
    {
		public void actionPerformed(ActionEvent ae) 
		{
			ipan2 = new IP2();
			
			mp.removeAll();
			mp.repaint();
			mp.revalidate();
			mp.add(ipan2);
			mp.repaint();
			mp.revalidate();
		}
	}
	
	public class insert3 implements ActionListener
    {
		public void actionPerformed(ActionEvent ae) 
		{
			ipan3 = new IP3();
			
			mp.removeAll();
			mp.repaint();
			mp.revalidate();
			mp.add(ipan3);
			mp.repaint();
			mp.revalidate();
		}
	}
	
	public class insert4 implements ActionListener
    {
		public void actionPerformed(ActionEvent ae) 
		{
			ipan4 = new IP4();
			
			mp.removeAll();
			mp.repaint();
			mp.revalidate();
			mp.add(ipan4);
			mp.repaint();
			mp.revalidate();
		}
	}
	
	public class update1 implements ActionListener
    {
		public void actionPerformed(ActionEvent ae) 
		{
			upan1 = new UP1();
			
			mp.removeAll();
			mp.repaint();
			mp.revalidate();
			mp.add(upan1);
			mp.repaint();
			mp.revalidate();
		}
	}
	
	
	public class update2 implements ActionListener
    {
		public void actionPerformed(ActionEvent ae) 
		{
			upan2 = new UP2();
			
			mp.removeAll();
			mp.repaint();
			mp.revalidate();
			mp.add(upan2);
			mp.repaint();
			mp.revalidate();
		}
	}
	
	
	public class update3 implements ActionListener
    {
		public void actionPerformed(ActionEvent ae) 
		{
			upan3 = new UP3();
			
			mp.removeAll();
			mp.repaint();
			mp.revalidate();
			mp.add(upan3);
			mp.repaint();
			mp.revalidate();
		}
	}
	
	
	public class update4 implements ActionListener
    {
		public void actionPerformed(ActionEvent ae) 
		{
			upan4 = new UP4();
			
			mp.removeAll();
			mp.repaint();
			mp.revalidate();
			mp.add(upan4);
			mp.repaint();
			mp.revalidate();
		}
	}
	
	
	public class delete1 implements ActionListener
    {
		public void actionPerformed(ActionEvent ae) 
		{
			dpan1 = new DP1();
			
			mp.removeAll();
			mp.repaint();
			mp.revalidate();
			mp.add(dpan1);
			mp.repaint();
			mp.revalidate();
		}
	}
	
	public class delete2 implements ActionListener
    {
		public void actionPerformed(ActionEvent ae) 
		{
			dpan2 = new DP2();
			
			mp.removeAll();
			mp.repaint();
			mp.revalidate();
			mp.add(dpan2);
			mp.repaint();
			mp.revalidate();
		}
	}
	
	public class delete3 implements ActionListener
    {
		public void actionPerformed(ActionEvent ae) 
		{
			dpan3 = new DP3();
			
			mp.removeAll();
			mp.repaint();
			mp.revalidate();
			mp.add(dpan3);
			mp.repaint();
			mp.revalidate();
		}
	}
	
	public class delete4 implements ActionListener
    {
		public void actionPerformed(ActionEvent ae) 
		{
			dpan4 = new DP4();
			
			mp.removeAll();
			mp.repaint();
			mp.revalidate();
			mp.add(dpan4);
			mp.repaint();
			mp.revalidate();
		}
	}
	
	public class view1 implements ActionListener
    {
		public void actionPerformed(ActionEvent ae) 
		{
			vpan1 = new VP1();
			
			mp.removeAll();
			mp.repaint();
			mp.revalidate();
			mp.add(vpan1);
			mp.repaint();
			mp.revalidate();
		
		}
	}
	
	
	public class view2 implements ActionListener
    {
		public void actionPerformed(ActionEvent ae) 
		{
			vpan2 = new VP2();
			
			mp.removeAll();
			mp.repaint();
			mp.revalidate();
			mp.add(vpan2);
			mp.repaint();
			mp.revalidate();
		
		}
	}
	
	
	public class view3 implements ActionListener
    {
		public void actionPerformed(ActionEvent ae) 
		{
			vpan3 = new VP3();
			
			mp.removeAll();
			mp.repaint();
			mp.revalidate();
			mp.add(vpan3);
			mp.repaint();
			mp.revalidate();
		
		}
	}
	
	
	public class view4 implements ActionListener
    {
		public void actionPerformed(ActionEvent ae) 
		{
			vpan4 = new VP4();
			
			mp.removeAll();
			mp.repaint();
			mp.revalidate();
			mp.add(vpan4);
			mp.repaint();
			mp.revalidate();
		
		}
	}
	
}